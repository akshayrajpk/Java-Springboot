package com.example.javabasic.day2.interfaceDemo.functionalInterfaceDemo4;

//WeekDays interface declaration
public interface WeekDays {
    public void
    displaydays();
}
