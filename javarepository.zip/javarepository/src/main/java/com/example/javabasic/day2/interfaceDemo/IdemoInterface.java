package com.example.javabasic.day2.interfaceDemo;

public interface IdemoInterface {

}
