package com.example.javabasic.day7.junit_Mockito.mockito.program3;

public class Numbers {
    public static boolean isOdd(int number) {
        return number % 2 != 0;
    }
}
