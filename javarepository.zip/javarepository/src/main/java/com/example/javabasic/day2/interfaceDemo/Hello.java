package com.example.javabasic.day2.interfaceDemo;

import com.example.javabasic.day2.interfaceDemo.functionalInterface.Test;

public class Hello {
    public static void main(String[] args) {
        //System.out.println("Hello");
        //Test test = new Test();
        //System.out.println(test.display());// Method Calling
    }
}
