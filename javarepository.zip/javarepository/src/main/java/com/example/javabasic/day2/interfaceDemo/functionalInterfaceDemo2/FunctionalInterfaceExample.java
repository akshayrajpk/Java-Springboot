package com.example.javabasic.day2.interfaceDemo.functionalInterfaceDemo2;

//implementation of Functional Interface
class FunctionalInterfaceExample implements Function_Interface {
    public void disp_msg(String msg) {
        System.out.println(msg);
    }
}
