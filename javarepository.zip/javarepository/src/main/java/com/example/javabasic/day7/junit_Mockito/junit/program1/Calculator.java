package com.example.javabasic.day7.junit_Mockito.junit.program1;

public class Calculator {

    public int multiply(int a, int b) {
        return a * b;
    }
}
