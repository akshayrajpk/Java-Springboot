package com.example.javabasic.day2.interfaceDemo.Akshay;

public class DemoMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Demo demo = new Demo();
		demo.nonStaticDemoMethod();
		IDemoInterface.staticDemoMethod();

	}

}
