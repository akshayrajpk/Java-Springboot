package com.example.javabasic.exercise.day2;

public class Demo implements IDemoInterface {
	 @Override
	    public void nonStaticDemoMethod() {
	        System.out.println("Its a demo ");
	    }
}
