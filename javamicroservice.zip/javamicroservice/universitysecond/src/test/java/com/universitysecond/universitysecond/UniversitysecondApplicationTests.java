package com.universitysecond.universitysecond;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UniversitysecondApplicationTests {

	@Test
	void contextLoads() {
	}

}
