package com.example.javabasic.day2.interfaceDemo;

public interface ITest {
    String display();// Method Declaration
}
