package com.example.javabasic.exercise.day1;

public class Demo implements IDemoInterface {
	 @Override
	    public void nonStaticDemoMethod() {
	        System.out.println("Its a demo ");
	    }
}
