package com.example.javabasic.day7.junit_Mockito.mockito.program1;

class Database {

    public boolean isAvailable() {
        // TODO implement the access to the database
        return false;
    }
    public int getUniqueId() {
        return 42;
    }
}
