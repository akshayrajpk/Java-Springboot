https://www.section.io/engineering-education/spring-boot-rest-template/

https://www.amitph.com/introduction-to-spring-webclient/
