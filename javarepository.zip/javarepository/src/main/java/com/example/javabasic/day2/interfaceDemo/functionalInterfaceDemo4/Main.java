package com.example.javabasic.day2.interfaceDemo.functionalInterfaceDemo4;

public class Main {
    public static void main(String[] args) {
        Days.MONDAY.displaydays();//access enum value
        Days.SATURDAY.test();
    }
}
