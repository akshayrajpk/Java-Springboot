package com.client.demo.service;

public interface DepartmentService {
    public String getDepById(int id);
}
