package com.example.javabasic.Exercise.Day17;

public class Test {
}
