Encoding URL: https://bcrypt-generator.com/

POST:
localhost:8080/authenticate
Payload:
{
    "username": "cgiuser",
    "password": "password"
}
