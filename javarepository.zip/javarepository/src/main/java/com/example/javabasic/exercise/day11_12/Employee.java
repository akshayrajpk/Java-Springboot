package com.example.javabasic.exercise.day11_12;

public class Employee {
    String Field;
    Float Salary;

    public void setField(String field){
        this.Field = field;
    }

    public void setSalary(Float salary){
        this.Salary = salary;
    }

    public String getField(){
        return Field;
    }

    public Float getSalary(){
        return Salary;
    }
}
