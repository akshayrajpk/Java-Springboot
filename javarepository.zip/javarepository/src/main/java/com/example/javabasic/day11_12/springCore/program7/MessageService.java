package com.example.javabasic.day11_12.springCore.program7;

public interface MessageService {

	boolean sendMessage(String msg, String rec);
}
