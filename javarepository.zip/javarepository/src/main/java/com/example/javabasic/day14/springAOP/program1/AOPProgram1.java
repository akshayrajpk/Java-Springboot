package com.example.javabasic.day14.springAOP.program1;

public class AOPProgram1 {
    public void m() {
        //Actual Business Logic
        System.out.println("------------ACTUAL BUSINESS LOGIC START -------------");
        System.out.println("##### ACTUAL BUSINESS LOGIC ####");
        System.out.println("------------ACTUAL BUSINESS LOGIC END -------------");
    }
}  
