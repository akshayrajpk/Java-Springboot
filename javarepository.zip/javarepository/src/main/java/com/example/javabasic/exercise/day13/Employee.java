package com.example.javabasic.exercise.day13;

public class Employee {
    private String name;
    private String add;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAddress() {
        return add;
    }

    public void setAddress(String address) {
        this.add = address;
    }

}
