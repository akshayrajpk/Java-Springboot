create table employee(
id int(10),
name varchar(100),
salary int(10)
);
