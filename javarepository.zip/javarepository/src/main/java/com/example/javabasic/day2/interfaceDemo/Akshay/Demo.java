package com.example.javabasic.day2.interfaceDemo.Akshay;

public class Demo implements IDemoInterface{
	 @Override
	    public void nonStaticDemoMethod() {
	        System.out.println("Its a demo ");
	    }
}
