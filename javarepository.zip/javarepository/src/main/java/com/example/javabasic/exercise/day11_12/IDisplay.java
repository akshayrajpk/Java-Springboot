package com.example.javabasic.exercise.day11_12;

public interface IDisplay {
    public void display(String msg);
}
