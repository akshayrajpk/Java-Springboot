package com.example.javabasic.Exercise.Day16;

public class Test {
}
